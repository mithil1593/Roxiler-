function Power(appliance) {
    alert(appliance.charAt(0).toUpperCase() + appliance.slice(1) + " Operated");
}

function Temperature(value) {
    alert("AC temperature set to " + value + "°C");
}

function FanSpeed(value) {
    alert("Fan speed set to " + value);
}

function adjustBrightness(value) {
    alert("Light brightness adjusted to " + value + "%");
}

function changeColor(value) {
    alert("Light color changed to " + value);
}